#!/bin/bash  

# Get PID for MDATP processes

RUN_DATE=$(date +%Y-%m-%d-%H%M)

EDR=0
AV_SCAN=0
TELEMETRY=0
CAMP=0
AUDISP=0

while [[ $# -gt 0 ]]; do
current_arg="$1"

case $current_arg in
  --camp)
  CAMP=1
  shift
  ;;
  --edr)
  EDR=1
  shift
  ;;
  --avscan)
  AV_SCAN=1
  shift
  ;;
  --telemetry)
  TELEMETRY=1
  shift
  ;;
  --audisp)
  AUDISP=1
  shift
  ;;
  *)
  break
  ;;
esac
done


if [ "$AUDISP" -eq 1 ]; then
   audisp_procs=$(pgrep mdatp_audisp_pl)
   audisp_procs_cnt=$(echo "$audisp_procs" | wc -w)
   if [ "$audisp_procs_cnt" -eq 1 ]; then
     echo $audisp_procs
   else
     echo "-1"
   fi
   exit 0
fi

if [ "$TELEMETRY" -eq 1 ]; then
   MDATP_TELEMETRYD_PID=$(pgrep telemetryd)
   echo $MDATP_TELEMETRYD_PID
   exit 0
fi

CAMP_PID=
if [ "$CAMP" -eq 1 ] || [ "$EDR" -eq 1 ] ||  [ "$AV_SCAN" -eq 1 ]; then
    wdavd_procs=$(pgrep wdavdaemon)
    for proc_pid in $wdavd_procs; do
       proc_ppid=$(ps -p "$proc_pid" -o ppid | grep -v PPID) || (echo "Failed getting process info for PID=$proc_pid" ; exit 1)
       if [ "$proc_ppid" -eq 1 ]; then # A process with parent PID 1
          CAMP_PID=$proc_pid
          if [ $CAMP -eq 1 ]; then
	           echo $CAMP_PID
	           exit 0
          fi
       fi
    done
fi

if [ -z "$CAMP_PID" ]; then echo "Failed to find daemon process"; exit 1; fi

EDR_PID=
AVSCAN_PID=
for proc_pid in $wdavd_procs; do
  proc_ppid=$(ps -p "$proc_pid" -o ppid | grep -v PPID) || (echo "Failed getting process info for PID=$proc_pid" ; exit 1)
  if [ "$proc_ppid" -eq "$CAMP_PID" ]; then # Child of daemon process
    # Check owning user - EDR owned by root and AVSCAN owned by _mdatp
    proc_user=$(ps -p "$proc_pid" -o user | grep -v USER) || (echo "Failed getting process info for PID=$proc_pid" ; exit 1)
    if [ "$proc_user" == root ]; then
      EDR_PID=$proc_pid
      if [ "$EDR" -eq 1 ]; then
         echo "$EDR_PID"
         exit 0
      fi
    elif [ "$proc_user" == _mdatp ] || [ "$proc_user" == mdatp ]; then
      AVSCAN_PID=$proc_pid
      if [ "$AV_SCAN" -eq 1 ]; then
         echo "$AVSCAN_PID"
         exit 0
      fi
    else
      echo "Invalid user for PID=$proc_pid"
      ps -p "$proc_pid" -o user,ppid,pid,comm
      exit 1
    fi
  fi
done # Lookup daemon process

echo "-1"

