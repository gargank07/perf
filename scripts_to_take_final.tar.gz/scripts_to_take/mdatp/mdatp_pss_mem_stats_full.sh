#!/bin/bash -f 

DATA_SCRIPT_ROOT="$( cd "$(dirname "$0")" ; pwd -P )" || exit
export DATA_SCRIPT_DIR=$DATA_SCRIPT_ROOT

camp_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --camp)
edr_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --edr)
avscan_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --avscan)
audisp_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --audisp)
telemetry_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --telemetry)

total=$(echo "$camp_mem + $edr_mem + $avscan_mem + $audisp_mem + $telemetry_mem" | bc)
echo $total
