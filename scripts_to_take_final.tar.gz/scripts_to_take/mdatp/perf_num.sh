#!/bin/bash

DATA_SCRIPT_ROOT="$( cd "$(dirname "$0")" ; pwd -P )" || exit
export DATA_SCRIPT_DIR=$DATA_SCRIPT_ROOT

PID1=$($DATA_SCRIPT_ROOT/get_pid_mdatp.sh --camp)
PID2=$($DATA_SCRIPT_ROOT/get_pid_mdatp.sh --edr)
PID3=$($DATA_SCRIPT_ROOT/get_pid_mdatp.sh --avscan)
PID4=$($DATA_SCRIPT_ROOT/get_pid_mdatp.sh --telemetry)

echo "Monitoring for CPU/Memory Sampling at=>$1 CAMP=>$PID1, EDR=>$PID2, ENGINE=>$PID3, TELEMETRY=$PID3" | tee perf_num_mdatp.log
echo "TOTAL CORES = $(nproc)" | tee -a perf_num_mdatp.log
echo "" | tee -a perf_num_mdatp.log

# Collect CPU usage every second
while [ 1 ] ; do
        TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")
	total_cpu=0
	total_mem=0

	if  ps -p $PID1 > /dev/null 2>&1; then
    	   CPU=$(ps -p $PID1 -o %cpu --no-headers)
	   mem=$(python3 $DATA_SCRIPT_ROOT/pss_mem_stats.py $PID1)
	   total_cpu=$( echo "($total_cpu + $CPU)" | bc )
	   total_mem=$( echo "($total_mem + $mem)" | bc )
	   echo "$TIMESTAMP: Process CAMP CPU => $CPU, Memory PSS: $mem" | tee -a perf_num_mdatp.log
	fi

	if  ps -p $PID2 > /dev/null 2>&1; then
    	   CPU=$(ps -p $PID2 -o %cpu --no-headers)
	   mem=$(python3 $DATA_SCRIPT_ROOT/pss_mem_stats.py $PID2)
	   total_cpu=$( echo "($total_cpu + $CPU)" | bc )
	   total_mem=$( echo "($total_mem + $mem)" | bc )
	   echo "$TIMESTAMP: Process EDR CPU => $CPU, Memory PSS: $mem" | tee -a perf_num_mdatp.log
	fi

	if  ps -p $PID3 > /dev/null 2>&1; then
    	   CPU=$(ps -p $PID3 -o %cpu --no-headers)
	   mem=$(python3 $DATA_SCRIPT_ROOT/pss_mem_stats.py $PID3)
	   total_cpu=$( echo "($total_cpu + $CPU)" | bc )
	   total_mem=$( echo "($total_mem + $mem)" | bc )
	   echo "$TIMESTAMP: Process ENGINE CPU => $CPU, Memory PSS: $mem" | tee -a perf_num_mdatp.log
	fi

	if  ps -p $PID4 > /dev/null 2>&1; then
    	   CPU=$(ps -p $PID4 -o %cpu --no-headers)
	   mem=$(python3 $DATA_SCRIPT_ROOT/pss_mem_stats.py $PID4)
	   total_cpu=$( echo "($total_cpu + $CPU)" | bc )
	   total_mem=$( echo "($total_mem + $mem)" | bc )
	   echo "$TIMESTAMP: Process TELEMETRY CPU => $CPU, Memory PSS: $mem" | tee -a perf_num_mdatp.log
	fi
	echo "$TIMESTAMP: Total CPU => $total_cpu, Total MEM PSS => $total_mem" | tee -a perf_num_mdatp.log
	echo "" | tee -a perf_num_mdatp.log
        sleep $1
done

