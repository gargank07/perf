#!/bin/bash -f 
export RAMDISK_PATH=/mnt/RamDisk
init_ram_disk() {
    #mkdir -p /tmp/ramDisk
    mkdir -p $RAMDISK_PATH
    grep "$RAMDISK_PATH" /etc/fstab

    if [ $? -eq 0 ]; then
        echo "Mapping exist skipping"
    else
        echo "tmpfs     $RAMDISK_PATH    tmpfs     rw,size=3G,x-gvfs-show     0 0" >> /etc/fstab
        mount -a
    fi

    rm -fr "$RAMDISK"/dump*
}

init_ram_disk
