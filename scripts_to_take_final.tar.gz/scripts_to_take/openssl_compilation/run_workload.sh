#!/bin/bash -f 


SCRIPT_ROOT="$( cd "$(dirname "$0")" ; pwd -P )" || exit
export SCRIPT_DIR=$SCRIPT_ROOT

$SCRIPT_DIR/setup_ram_disk.sh
$SCRIPT_DIR/perf_workload_setup.sh
$SCRIPT_DIR/workload.sh
