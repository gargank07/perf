#!/bin/bash -f 

## This script will generate different workload scenario by usin the fio

#check if variable RAMDISK_PATH is set
export RAMDISK_PATH=/mnt/RamDisk
if [ -z "${RAMDISK_PATH}" ]; then
   echo "Please set the RAMDISK_PATH environment variable pointing to ramdisk directory to procceed"
   exit 1
fi

#sudo apt remove openssl -y
sudo rm -fr ${RAMDISK_PATH}/openssl
mkdir -p ${RAMDISK_PATH}/openssl/
cd ${RAMDISK_PATH}/openssl/

sudo yum install -y tar
sudo yum install -y perl
sudo yum install -y make
#git clone https://github.com/openssl/openssl.git
curl -L -O https://www.openssl.org/source/openssl-1.1.1f.tar.gz || exit 2


