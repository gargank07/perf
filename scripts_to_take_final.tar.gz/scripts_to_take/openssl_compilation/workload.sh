#!/bin/bash -f
SCENARIO=""
OUTDIR=""
CYCLES=1
DUMP_PATH=""
RUN_SCAN=0

export RAMDISK_PATH=/mnt/RamDisk


while [[ $# -gt 0 ]]; do
current_arg="$1"

case $current_arg in
  --outdir)
  OUTDIR="$2"
  shift
  shift
  ;;
  --dump_path)
  DUMP_PATH="$2"
  shift
  shift
  ;;
  --scenario)
  SCENARIO="$2"
  shift
  shift
  ;;
  --cycles)
  CYCLES="$2"
  shift
  shift
  ;;
  --schedule_scan)
  RUN_SCAN=1
  shift
  ;;

esac
done

#check if variable RAMDISK_PATH is set
if [ -z "${RAMDISK_PATH}" ]; then
   echo "Please set the RAMDISK_PATH environment variable pointing to ramdisk directory to procceed"
   exit 1
fi


cd ${RAMDISK_PATH}/openssl/


build_pkg() {

  mkdir build
  cd build

  echo "Unpacking openssl-1.1.1f.tar.gz  ..."
  if ! tar xf ../openssl-1.1.1f.tar.gz ; then
    echo "Unpacking of openssl-1.1.1f.tar.gz  failed."
    return 1
  fi

  cd openssl-1.1.1f

  echo "Configuring openssl ..."
  ./Configure linux-x86_64 no-asm

  echo "Compiling openssl ..."

  if ! make; then
    echo "Build of openssl failed."
    return 3
  fi

  cd ..
  cd ..
  rm -rf build

  return 0
}


while [ 1 ] ;  
do 
   build_pkg
done

