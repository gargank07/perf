#!/bin/bash -f
SCENARIO=""
OUTDIR=""
CYCLES=1
DUMP_PATH=""
RUN_SCAN=0


while [[ $# -gt 0 ]]; do
current_arg="$1"

case $current_arg in
  --outdir)
  OUTDIR="$2"
  shift
  shift
  ;;
  --dump_path)
  DUMP_PATH="$2"
  shift
  shift
  ;;
  --scenario)
  SCENARIO="$2"
  shift
  shift
  ;;
  --cycles)
  CYCLES="$2"
  shift
  shift
  ;;
  --schedule_scan)
  RUN_SCAN=1
  shift
  ;;

esac
done


if [ -z "${SCRIPT_DIR}" ]; then
   echo "Please set the SCRIPT_DIR environment variable pointing to script directory to procceed"
   exit 1
fi


$SCRIPT_DIR/run.sh 4

if [ $RUN_SCAN -eq 1 ]; then
    mdatp scan custom --path $DUMP_PATH 
fi
