#!/bin/bash 
# setup steps before running postgresql workload
# re-mount ramdisk with noexec option
# install and setup postgresql

DISTRO=
VERSION=
VERSION_NAME=
DISTRO_FAMILY=
PKG_MGR=
PKG_MGR_INVOKER=
RAMDISK_PATH=/mnt/RamDisk
detect_distro()
{
    if [ -f /etc/os-release ] || [ -f /etc/mariner-release ]; then
        . /etc/os-release
        DISTRO=$ID
        VERSION=$VERSION_ID
        VERSION_NAME=$VERSION_CODENAME
    elif [ -f /etc/redhat-release ]; then
        if [ -f /etc/oracle-release ]; then
            DISTRO="ol"
        elif [[ $(grep -o -i "Red\ Hat" /etc/redhat-release) ]]; then
            DISTRO="rhel"
        elif [[ $(grep -o -i "Centos" /etc/redhat-release) ]]; then
            DISTRO="centos"
        fi
        VERSION=$(grep -o "release .*" /etc/redhat-release | cut -d ' ' -f2)
    else
        script_exit "unable to detect distro" $ERR_UNSUPPORTED_DISTRO
    fi

    # change distro to ubuntu for linux mint support
    if [ "$DISTRO" == "linuxmint" ]; then
        DISTRO="ubuntu"
    fi

    if [ "$DISTRO" == "debian" ] || [ "$DISTRO" == "ubuntu" ]; then
        DISTRO_FAMILY="debian"
    elif [ "$DISTRO" == "rhel" ] || [ "$DISTRO" == "centos" ] || [ "$DISTRO" == "ol" ] || [ "$DISTRO" == "fedora" ] || [ "$DISTRO" == "amzn" ]; then
        DISTRO_FAMILY="fedora"
    elif [ "$DISTRO" == "mariner" ]; then
        DISTRO_FAMILY="mariner"
    elif [ "$DISTRO" == "sles" ] || [ "$DISTRO" == "sle-hpc" ] || [ "$DISTRO" == "sles_sap" ]; then
        DISTRO_FAMILY="sles"
    else
        script_exit "unsupported distro $DISTRO $VERSION" $ERR_UNSUPPORTED_DISTRO
    fi

    echo "[>] detected: $DISTRO $VERSION $VERSION_NAME ($DISTRO_FAMILY)"
}

set_package_manager()
{
    if [ "$DISTRO_FAMILY" = "debian" ]; then
        PKG_MGR=apt
        PKG_MGR_INVOKER="apt -y"
    elif [ "$DISTRO_FAMILY" = "fedora" ]; then
        PKG_MGR=yum
        PKG_MGR_INVOKER="yum -y"
    elif [ "$DISTRO_FAMILY" = "mariner" ]; then
        PKG_MGR=dnf
        PKG_MGR_INVOKER="dnf -y"
    elif [ "$DISTRO_FAMILY" = "sles" ]; then
        DISTRO="sles"
        PKG_MGR="zypper"
        PKG_MGR_INVOKER="zypper --non-interactive"
    else    
        script_exit "unsupported distro", $ERR_UNSUPPORTED_DISTRO
    fi

    echo "[v] set package manager: $PKG_MGR"
}

init_ram_disk() {
    mkdir -p "$RAMDISK_PATH"
    grep "$RAMDISK_PATH" /etc/fstab

    if [ $? -eq 0 ]; then
        #If entry alreasy exists, delete existing entries and add new noexec entry
        line_nums=$(grep -n "$RAMDISK_PATH" /etc/fstab | cut -f1 -d:)
        pattern=
        for line_num in $line_nums;
        do
            pattern="${pattern};${line_num}d"
        done

        sed "$pattern" /etc/fstab > /tmp/fstab
        echo "tmpfs     $RAMDISK_PATH    tmpfs     rw,size=3G,x-gvfs-show     0 0" >> /tmp/fstab
        mv /tmp/fstab /etc/fstab
        mount -a
    else
        echo "tmpfs     $RAMDISK_PATH    tmpfs     rw,size=3G,x-gvfs-show     0 0" >> /etc/fstab
        mount -a
    fi

    rm -fr "$RAMDISK"/dump*
}

if [ -z "${RAMDISK_PATH}" ]; then
   echo "Please set the RAMDISK_PATH environment variable pointing to ram disk for the files to dump"
   exit 1
fi

init_ram_disk
detect_distro
set_package_manager

eval "sudo $PKG_MGR_INVOKER install python3-numpy"

eval "sudo $PKG_MGR_INVOKER install postgresql"
eval "sudo $PKG_MGR_INVOKER install postgresql-server"
sudo useradd postgres -s /sbin/nologin
sudo rm -fr "$RAMDISK_PATH"/postgres_data
sudo mkdir "$RAMDISK_PATH"/postgres_data
sudo chown postgres "$RAMDISK_PATH"/postgres_data

#version=$(ls /usr/lib/postgresql/)
export POSTGRES_BIN_PATH=/usr/bin
echo "export POSTGRES_BIN_PATH=$POSTGRES_BIN_PATH" > $HOME/postgres_env.sh

sudo -u postgres "$POSTGRES_BIN_PATH"/initdb -D "$RAMDISK_PATH"/postgres_data
sudo systemctl stop postgresql

sudo touch "$RAMDISK_PATH"/logfile.txt
sudo chmod 666 "$RAMDISK_PATH"/logfile.txt
#sudo chmod o+w /var/run/postgresql
sudo chown -R postgres:postgres /var/run/postgresql

sleep 15

sudo -u postgres "$POSTGRES_BIN_PATH"/pg_ctl -D "$RAMDISK_PATH"/postgres_data -l "$RAMDISK_PATH"/logfile.txt start


echo "SETUP SUCCESSFUL"
