#!/bin/bash
source $HOME/postgres_env.sh

thread_num=$1

if ! [[ "$thread_num" =~ ^[0-9]+$ ]]
    then
        thread_num=1
fi

create_db() {
sudo -u postgres "$POSTGRES_BIN_PATH"/dropdb --if-exists testdb$1
sudo -u postgres "$POSTGRES_BIN_PATH"/createdb testdb$1
sudo -u postgres "$POSTGRES_BIN_PATH"/psql -c "grant all privileges on database testdb$1 to postgres";
}

do_test() {
    create_db $1
    "$POSTGRES_BIN_PATH"/psql -U postgres testdb$1 -c "drop table if exists test_table;"
    "$POSTGRES_BIN_PATH"/psql -U postgres testdb$1 -c "CREATE TABLE test_table (I SMALLINT NOT NULL, DT TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, F1 VARCHAR(4) NOT NULL, F2 VARCHAR(16) NOT NULL);"

    for i in {1..3}
    do
    	while read -r line; 
    	do
        	"$POSTGRES_BIN_PATH"/psql -U postgres testdb$1 -c "$line" >& /dev/null
    	done < $SCRIPT_DIR/sql-queries.txt
    done
}
pids=""
for i in $(seq 1 $thread_num)
do
    do_test $i &
    pids="$pids $!"
done
wait $pids
