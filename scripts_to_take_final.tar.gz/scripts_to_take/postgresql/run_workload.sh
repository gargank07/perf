#!/bin/bash -f 


SCRIPT_ROOT="$( cd "$(dirname "$0")" ; pwd -P )" || exit
export SCRIPT_DIR=$SCRIPT_ROOT

echo $SCRIPT_DIR
whoami

$SCRIPT_DIR/workload_setup.sh

while [ 1 ] ;
do
   $SCRIPT_DIR/workload.sh
done
