#!/bin/sh -f

DATA_SCRIPT_ROOT="$( cd "$(dirname "$0")" ; pwd -P )" || exit
export DATA_SCRIPT_DIR=$DATA_SCRIPT_ROOT

pid=$($DATA_SCRIPT_ROOT/get_pid_mdatp.sh $1)

if [ "$pid" =  "-1" ]; then
   echo 0
   exit 0
fi

mem_stat=$(python3 $DATA_SCRIPT_ROOT/pss_mem_stats.py $pid)
echo $mem_stat
