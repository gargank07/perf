#!/usr/bin/env python3
import sys
import psutil
import time
import numpy

p = psutil.Process(int(sys.argv[1]))
print(str(p.memory_full_info().pss/1048576))



