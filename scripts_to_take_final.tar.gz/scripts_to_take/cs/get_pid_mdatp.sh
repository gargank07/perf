#!/bin/bash  

# Get PID for MDATP processes

RUN_DATE=$(date +%Y-%m-%d-%H%M)

PROC1=0
PROC2=0
PROC3=0
PROC4=0

while [[ $# -gt 0 ]]; do
current_arg="$1"

case $current_arg in
  --falconsensorbpf)
  PROC1=1
  shift
  ;;
  --falcond)
  PROC2=1
  shift
  ;;
  --falconfx)
  PROC3=1
  shift
  ;;
  --falconpredict)
  PROC4=1
  shift
  ;;
  *)
  break
  ;;
esac
done


if [ "$PROC1" -eq 1 ]; then
   audisp_procs=$(pgrep falcon-sensor)
   audisp_procs_cnt=$(echo "$audisp_procs" | wc -w)
   if [ "$audisp_procs_cnt" -eq 1 ]; then
     echo $audisp_procs
   else
     echo "-1"
   fi
   exit 0
fi

if [ "$PROC2" -eq 1 ]; then
   audisp_procs=$(pgrep falcond)
   audisp_procs_cnt=$(echo "$audisp_procs" | wc -w)
   if [ "$audisp_procs_cnt" -eq 1 ]; then
     echo $audisp_procs
   else
     echo "-1"
   fi
   exit 0
fi

if [ "$PROC3" -eq 1 ]; then
   audisp_procs=$(pgrep falcon-fx)
   audisp_procs_cnt=$(echo "$audisp_procs" | wc -w)
   if [ "$audisp_procs_cnt" -eq 1 ]; then
     echo $audisp_procs
   else
     echo "-1"
   fi
   exit 0
fi

if [ "$PROC4" -eq 1 ]; then
   audisp_procs=$(pgrep falcon-predict)
   audisp_procs_cnt=$(echo "$audisp_procs" | wc -w)
   if [ "$audisp_procs_cnt" -eq 1 ]; then
     echo $audisp_procs
   else
     echo "-1"
   fi
   exit 0
fi


echo "-1"

