#!/bin/bash -f 

DATA_SCRIPT_ROOT="$( cd "$(dirname "$0")" ; pwd -P )" || exit
export DATA_SCRIPT_DIR=$DATA_SCRIPT_ROOT

proc1_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --falconsensorbpf)
proc2_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --falcond)
proc3_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --falconfx)
proc4_mem=$($DATA_SCRIPT_DIR/mdatp_pss_mem_stats.sh --falconpredict)


echo "Falcon Sensor BPF = $proc1_mem"
echo "Falcon Daemon = $proc2_mem"
echo "Falcon FX = $proc3_mem"
echo "Falcon PRedict = $proc4_mem"

total=$(echo "$proc1_mem + $proc2_mem + $proc3_mem + $proc4_mem" | bc)
echo $total
